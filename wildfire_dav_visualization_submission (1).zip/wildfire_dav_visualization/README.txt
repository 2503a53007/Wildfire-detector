Wildfire DAV Visualization Project

The uploaded CSV is included in data/raw/.
Open this folder in VS Code, run: pip install -r requirements.txt
Then run: python visualization.py
Six PNG charts will be saved in visualizations/.

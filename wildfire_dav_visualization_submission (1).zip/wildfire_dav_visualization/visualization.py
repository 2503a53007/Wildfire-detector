"""
DAV Project: Wildfire Detection Data Visualization
Dataset: MODIS fire_archive_M-C61_786974.csv

Run:
    pip install -r requirements.txt
    python visualization.py

Expected input:
    data/raw/fire_archive_M-C61_786974.csv

Output:
    Six PNG charts saved in visualizations/
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# Use the folder containing this Python file, not the terminal's current folder.
PROJECT_DIR = Path(__file__).resolve().parent
DATA_PATH = PROJECT_DIR / "data" / "raw" / "fire_archive_M-C61_786974.csv"
OUTPUT_DIR = PROJECT_DIR / "visualizations"

# India coordinate bounds used to focus the analysis on India.
# Remove this filter if your CSV contains detections from other countries
# and you want to analyse the entire dataset.
INDIA_ONLY = True
INDIA_LAT_MIN, INDIA_LAT_MAX = 6.0, 37.5
INDIA_LON_MIN, INDIA_LON_MAX = 68.0, 97.5

plt.rcParams.update({
    "figure.figsize": (10, 6),
    "axes.titlesize": 15,
    "axes.labelsize": 11,
    "font.size": 10
})


def load_data():
    """Load and prepare the uploaded wildfire CSV."""
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"CSV file not found: {DATA_PATH}\n"
            "Place fire_archive_M-C61_786974.csv inside data/raw/."
        )

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip().str.lower()

    required = [
        "latitude", "longitude", "acq_date", "confidence",
        "frp", "daynight"
    ]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(
            f"Missing required CSV columns: {missing}\n"
            f"Available columns: {df.columns.tolist()}"
        )

    # Convert columns to suitable data types.
    df["acq_date"] = pd.to_datetime(df["acq_date"], errors="coerce")
    for col in ["latitude", "longitude", "confidence", "frp"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=[
        "acq_date", "latitude", "longitude", "confidence", "frp"
    ])

    # Keep 2016–2025 records.
    df = df[df["acq_date"].dt.year.between(2016, 2025)].copy()

    if INDIA_ONLY:
        df = df[
            df["latitude"].between(INDIA_LAT_MIN, INDIA_LAT_MAX)
            & df["longitude"].between(INDIA_LON_MIN, INDIA_LON_MAX)
        ].copy()

    if df.empty:
        raise ValueError(
            "No records remain after date and location filtering. "
            "Check the dataset dates or set INDIA_ONLY = False."
        )

    df["year"] = df["acq_date"].dt.year
    df["month"] = df["acq_date"].dt.month
    df["daynight"] = df["daynight"].astype(str).str.strip().str.upper()

    print(f"Loaded {len(df):,} wildfire detection records.")
    print(f"Date range: {df['acq_date'].min().date()} to "
          f"{df['acq_date'].max().date()}")
    return df


def save_chart(filename):
    """Save the current Matplotlib chart and close it."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / filename, dpi=300, bbox_inches="tight")
    plt.show()
    plt.close()
    print(f"Saved: visualizations/{filename}")


def year_wise_trend(df):
    """Graph 1: Year-wise wildfire detection count."""
    yearly = df.groupby("year").size().reindex(range(2016, 2026), fill_value=0)

    plt.figure()
    plt.plot(
        yearly.index, yearly.values,
        marker="o", linewidth=2.5, color="orangered",
        label="Wildfire detections"
    )
    plt.title("Year-wise Wildfire Trend in India (2016–2025)")
    plt.xlabel("Year")
    plt.ylabel("Number of Wildfire Detections")
    plt.xticks(range(2016, 2026), rotation=45)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend()
    save_chart("1_year_wise_wildfire_trend.png")


def month_wise_distribution(df):
    """Graph 2: Month-wise wildfire detection count."""
    month_names = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ]
    monthly = df.groupby("month").size().reindex(range(1, 13), fill_value=0)

    plt.figure()
    bars = plt.bar(
        month_names, monthly.values,
        color="darkorange", edgecolor="firebrick",
        label="Wildfire detections"
    )
    plt.title("Month-wise Wildfire Distribution in India")
    plt.xlabel("Month")
    plt.ylabel("Number of Wildfire Detections")
    plt.grid(axis="y", linestyle="--", alpha=0.4)
    plt.legend()
    plt.bar_label(bars, fmt="%.0f", padding=2, fontsize=8)
    save_chart("2_month_wise_wildfire_distribution.png")


def assign_approx_region(row):
    """
    Assign broad approximate zones from latitude/longitude.
    These are not official Indian state or administrative boundaries.
    """
    lat, lon = row["latitude"], row["longitude"]

    if lat >= 25:
        return "North"
    if lat <= 15:
        return "South"
    if lon < 75:
        return "West"
    if lon >= 85:
        return "East"
    return "Central"


def region_wise_comparison(df):
    """Graph 3: Approximate geographical-zone comparison."""
    regional = df.apply(assign_approx_region, axis=1).value_counts()
    order = ["North", "South", "East", "West", "Central"]
    regional = regional.reindex(order, fill_value=0)

    plt.figure()
    bars = plt.bar(
        regional.index, regional.values,
        color=["firebrick", "orangered", "darkorange", "tomato", "peru"],
        label="Wildfire detections"
    )
    plt.title("Region-wise Wildfire Comparison in India")
    plt.xlabel("Approximate Geographical Region")
    plt.ylabel("Number of Wildfire Detections")
    plt.grid(axis="y", linestyle="--", alpha=0.4)
    plt.legend()
    plt.bar_label(bars, fmt="%.0f", padding=2, fontsize=8)
    save_chart("3_region_wise_wildfire_comparison.png")


def frp_analysis(df):
    """Graph 4: Average yearly Fire Radiative Power."""
    yearly_frp = df.groupby("year")["frp"].mean().reindex(range(2016, 2026))

    plt.figure()
    plt.plot(
        yearly_frp.index, yearly_frp.values,
        marker="o", linewidth=2.5, color="darkred",
        label="Average FRP"
    )
    plt.title("Year-wise Average Fire Radiative Power (FRP)")
    plt.xlabel("Year")
    plt.ylabel("Average Fire Radiative Power (MW)")
    plt.xticks(range(2016, 2026), rotation=45)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend()
    save_chart("4_fire_radiative_power.png")


def confidence_distribution(df):
    """Graph 5: Confidence categories for numeric MODIS confidence."""
    # MODIS numeric confidence is grouped as:
    # Low: <30, Nominal: 30–79, High: >=80.
    conditions = [
        df["confidence"] < 30,
        df["confidence"].between(30, 79),
        df["confidence"] >= 80
    ]
    labels = ["Low (<30)", "Nominal (30–79)", "High (80–100)"]
    df = df.copy()
    df["confidence_level"] = pd.Series(
        pd.NA, index=df.index, dtype="object"
    )
    for condition, label in zip(conditions, labels):
        df.loc[condition, "confidence_level"] = label

    counts = df["confidence_level"].value_counts().reindex(labels, fill_value=0)
    counts = counts[counts > 0]

    plt.figure(figsize=(8, 7))
    plt.pie(
        counts.values,
        labels=counts.index,
        autopct="%1.1f%%",
        startangle=90,
        colors=["gold", "darkorange", "firebrick"][:len(counts)],
        wedgeprops={"edgecolor": "white", "linewidth": 1}
    )
    plt.title("Confidence Level Distribution of Wildfire Detections")
    plt.legend(counts.index, title="Confidence Level", loc="best")
    save_chart("5_confidence_level_distribution.png")


def day_night_comparison(df):
    """Graph 6: Day versus night detection count."""
    counts = df["daynight"].value_counts().reindex(["D", "N"], fill_value=0)
    counts.index = ["Day", "Night"]

    plt.figure()
    bars = plt.bar(
        counts.index, counts.values,
        color=["orange", "darkred"],
        label="Wildfire detections"
    )
    plt.title("Day vs Night Wildfire Detection Comparison")
    plt.xlabel("Detection Time")
    plt.ylabel("Number of Wildfire Detections")
    plt.grid(axis="y", linestyle="--", alpha=0.4)
    plt.legend()
    plt.bar_label(bars, fmt="%.0f", padding=2)
    save_chart("6_day_vs_night_comparison.png")


def generate_visualizations():
    df = load_data()
    year_wise_trend(df)
    month_wise_distribution(df)
    region_wise_comparison(df)
    frp_analysis(df)
    confidence_distribution(df)
    day_night_comparison(df)
    print("\nAll six wildfire visualizations have been generated successfully!")


if __name__ == "__main__":
    generate_visualizations()

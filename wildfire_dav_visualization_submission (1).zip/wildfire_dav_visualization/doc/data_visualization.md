# Wildfire Detection Data Visualization

## Project objective
This module visualizes the MODIS wildfire detection dataset for the period 2016–2025. The program uses the supplied CSV columns and creates six charts for the DAV project.

## Dataset
Input file: `data/raw/fire_archive_M-C61_786974.csv`

Relevant columns:
- `acq_date`: date of satellite detection
- `latitude`, `longitude`: detection coordinates
- `frp`: Fire Radiative Power (MW)
- `confidence`: numeric confidence score
- `daynight`: `D` for daytime and `N` for nighttime

The CSV also contains `brightness`, `satellite`, `instrument`, `acq_time`, and `type`.

## Visualizations generated
1. **Year-wise Wildfire Trend Chart** — line chart showing yearly detection counts from 2016 to 2025.
2. **Month-wise Wildfire Distribution Chart** — bar chart showing detection counts for each calendar month.
3. **Region-wise Wildfire Comparison Chart** — bar chart comparing broad approximate North, South, East, West, and Central zones derived from latitude and longitude. These zones are not official state boundaries.
4. **Fire Radiative Power (FRP) Chart** — line chart showing average yearly FRP in megawatts.
5. **Confidence Level Distribution Chart** — pie chart grouping numeric confidence as Low (<30), Nominal (30–79), and High (80–100).
6. **Day vs Night Comparison Chart** — bar chart comparing daytime (`D`) and nighttime (`N`) detections.

All charts include titles, axis labels where applicable, and legends.

## How to run
1. Open this project folder in VS Code.
2. Open the terminal in VS Code.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python visualization.py
   ```
5. Find the generated PNG files in the `visualizations/` folder.

## Data filtering and interpretation
The script keeps records dated 2016–2025 and, by default, applies approximate India coordinate bounds (latitude 6.0–37.5 and longitude 68.0–97.5). To visualize all locations in the CSV, set `INDIA_ONLY = False` near the top of `visualization.py`.

The charts count satellite detection records. A detection record should not automatically be interpreted as a unique individual fire; one fire may produce multiple satellite detections. Region assignment is approximate and should not be described as state-wise analysis.
